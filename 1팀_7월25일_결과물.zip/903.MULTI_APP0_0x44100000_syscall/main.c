#include "Device_Driver.h"

//#include ".\images\image0.h"
//#include ".\images\img101.h"
#include ".\images\imgf1.h"
#include ".\images\imgf2.h"
#include ".\images\imgf3.h"
#include ".\images\imgf4.h"
//#include ".\images\imgf1_sunset.h"
#include ".\images\imgf2_sunset.h"
#include ".\images\imgf3_sunset.h"
#include ".\images\imgf4_sunset.h"
#include ".\images\imgf5_sunset.h"

#define BLACK	0x0000
#define WHITE	0xffff
#define BLUE	0x001f
#define GREEN	0x07e0
#define RED		0xf800
#define YELLOW	0xffe0
#define VIOLET	0xf81f
#define DELAY	5000

WIN_INFO_ST ArrWinInfo[5];
WIN_INFO_ST ArrWinInfo_2[5];

unsigned int car_speed;

//const unsigned short * img[]={imgf1, imgf3, imgf4, imgf1_sunset, imgf3_sunset};
const unsigned short * img[]={imgf2_sunset, imgf3_sunset, imgf4_sunset, imgf5_sunset};
const unsigned short * img_sun[]={imgf1, imgf2, imgf3, imgf4};

void Main(void)
{
	int tmp = 0;		//�ӵ� ��� ����
	int tmp_prv = 0;	//���� �ӵ� ��� ��
	int index = 0;
	_Uart_Printf(">>APP0 => LCD Display\n");

	/* �̹����� ���� ArrWinInfo �ʱ�ȭ */
	ArrWinInfo[0].bpp_mode = BPPMODE_16BPP_565;
	ArrWinInfo[0].bytes_per_pixel = 2;
	ArrWinInfo[0].p_sizex = 1024;
	ArrWinInfo[0].p_sizey = 600;
	ArrWinInfo[0].v_sizex = 1024;
	ArrWinInfo[0].v_sizey = 600;
	ArrWinInfo[0].posx = (1024 - ArrWinInfo[0].p_sizex) / 2;
	ArrWinInfo[0].posy = (600 - ArrWinInfo[0].p_sizey) / 2;
	/* ����� ���� ArrWinInfo �ʱ�ȭ */
	ArrWinInfo_2[0].bpp_mode = BPPMODE_16BPP_565;
	ArrWinInfo_2[0].bytes_per_pixel = 2;
	ArrWinInfo_2[0].p_sizex = 1024;
	ArrWinInfo_2[0].p_sizey = 600;
	ArrWinInfo_2[0].v_sizex = 1024;
	ArrWinInfo_2[0].v_sizey = 600;
	ArrWinInfo_2[0].posx = (1024 - 600) / 2;
	ArrWinInfo_2[0].posy = (600 - ArrWinInfo[0].p_sizey) / 2;


	_Lcd_Init(ArrWinInfo);
	_Lcd_Win_Init(0, 1, ArrWinInfo);
	_Lcd_Brightness_Control(8);

	_Lcd_Select_Display_Frame_Buffer(0, 0);
	_Lcd_Select_Draw_Frame_Buffer(0, 0);
	_Lcd_Clr_Screen(ArrWinInfo);

	/* ȭ�� ��� ä��� : �� */
	_Lcd_Draw_Back_Color(0x284b, ArrWinInfo_2);
	_Lcd_Draw_BMP(0,0,img[0]);

	/* 1. �극��ũ ��� ������ ��� */
	for(;;)
	{
		car_speed = _Get_Car_Speed();
		if(car_speed != 8000){
			_Lcd_Printf(850, 350, 0xffff, 0x284b, 2, 4, "Start!");
			_Delay(8000);
			_Lcd_Printf(850, 350, 0xffff, 0x284b, 2, 4, "Start!");
			_Delay(8000);
			_Lcd_Printf(850, 350, 0xffff, 0x284b, 2, 4, "Start!");
			_Delay(8000);
			break;
		}
	}

	_Lcd_Printf(850, 0, 0xffff, 0x284b, 2, 4, "                                            ");

	/* 2. �̹��� �ӵ� ���� �� �ӵ� ��� */
	for(;;)
	{
		index = 0;
		int image_size = sizeof(img)/sizeof(unsigned short *);

		for(; index < image_size ; index++){
			/* 2-1. ����� �ӵ� Ȯ�� */
			car_speed = _Get_Car_Speed();
			if(car_speed == 10000){		//===========================����
					//�ڷΰ���
					/* 2-2. ȭ�鿡 �ӵ� ��� */
					char speed_str[4];
					speed_str[0] = '\0';
					tmp = (car_speed - 10000 ) / 100;
					if((tmp != tmp_prv) && ((tmp_prv == 100)||(tmp_prv == 10))){
						_Lcd_Printf(850, 350, 0xffff, 0x284b, 2, 4, "   ");
					}

					tmp_prv = tmp;
					//snprintf(speed_str, sizeof(speed_str), "%d", tmp);
					sprintf(speed_str, "%d", tmp);
					_Uart_Printf(">>car_speed : %d, tmp : %d, speed_str : %s\n",car_speed, tmp, speed_str);
					_Lcd_Printf(850, 350, 0xffff, 0x284b, 2, 4, speed_str);
					_Lcd_Printf(850, 400, 0xffff, 0x284b, 2, 4, " KM / h");
				}
			else if(car_speed > 10000){		//===========================����
				//�ڷΰ���
				/* 2-2. ȭ�鿡 �ӵ� ��� */
				char speed_str[4];
				speed_str[0] = '\0';
				tmp = (car_speed - 10000 ) / 100;
				if((tmp != tmp_prv) && ((tmp_prv == 100)||(tmp_prv == 10)||(tmp_prv == 5))){
					_Lcd_Printf(850, 350, 0xffff, 0x284b, 2, 4, "   ");
				}

				tmp_prv = tmp;
				//snprintf(speed_str, sizeof(speed_str), "%d", tmp);
				sprintf(speed_str, "%d", tmp);
				_Uart_Printf(">>car_speed : %d, tmp : %d, speed_str : %s\n",car_speed, tmp, speed_str);
				_Lcd_Printf(850, 150, 0xffff, 0x284b, 2, 4, "REVERSE");
				_Lcd_Printf(850, 350, 0xffff, 0x284b, 2, 4, speed_str);
				_Lcd_Printf(850, 400, 0xffff, 0x284b, 2, 4, " KM / h");

				/* 2-3. �̹��� ���� */
				_Lcd_Draw_BMP(0,0,img[sizeof(img)/sizeof(unsigned short *)-index-1]);
				Delay(20000 - car_speed);
			}else{				//=============================================����
				/* 2-2. ȭ�鿡 �ӵ� ��� */
				_Lcd_Printf(850, 150, 0xffff, 0x284b, 2, 4, "       ");
				char speed_str[4];
				speed_str[0] = '\0';
				tmp = (10000 - car_speed ) / 100;
				if((tmp != tmp_prv) && ((tmp_prv == 100)||(tmp_prv == 10)||(tmp_prv == 5))){
					_Lcd_Printf(850, 350, 0xffff, 0x284b, 2, 4, "   ");
				}

				tmp_prv = tmp;
				//snprintf(speed_str, sizeof(speed_str), "%d", tmp);
				sprintf(speed_str, "%d", tmp);
				_Uart_Printf(">>car_speed : %d, tmp : %d, speed_str : %s\n",car_speed, tmp, speed_str);
				_Lcd_Printf(850, 350, 0xffff, 0x284b, 2, 4, speed_str);
				_Lcd_Printf(850, 400, 0xffff, 0x284b, 2, 4, " KM / h");

				/* 2-3. �̹��� ���� */
				_Lcd_Draw_BMP(0,0,img[index]);
				Delay(car_speed);
			}
		}
	}

}
