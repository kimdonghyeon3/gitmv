#include "Device_Driver.h"

#include ".\images\image_header.h"

extern WIN_INFO_ST ArrWinInfo[5];

#define BLACK	0x0000
#define WHITE	0xffff
#define BLUE	0x001f
#define GREEN	0x07e0
#define RED		0xf800
#define YELLOW	0xffe0
#define VIOLET	0xf81f

#define DELAY	4000

const unsigned short * img[]={img1, img2, img3, img4, img5, img6,
							  /*InD5_0000, InD5_0001, InD5_0002, InD5_0003, InD5_0004,
							  InD5_0005, InD5_0006, InD5_0007, InD5_0008, InD5_0009,
							  InD5_0010, InD5_0011, InD5_0012, InD5_0013, InD5_0014,
							  InD5_0015, InD5_0016, InD5_0017, InD5_0018, InD5_0019,
							  InD5_0020, InD5_0021, InD5_0022, InD5_0023, InD5_0024,
							  InD5_0025, InD5_0026,*/};

const unsigned short * warning_img = warning;

void Main(void)
{
	_Uart_Printf(">>APP0 => LCD Display\n");

	ArrWinInfo[0].bpp_mode = BPPMODE_16BPP_565;
	ArrWinInfo[0].bytes_per_pixel = 2;
	ArrWinInfo[0].p_sizex = 1024;
	ArrWinInfo[0].p_sizey = 600;
	ArrWinInfo[0].v_sizex = 1024;
	ArrWinInfo[0].v_sizey = 600;
	ArrWinInfo[0].posx = (1024 - ArrWinInfo[0].p_sizex) / 2;
	ArrWinInfo[0].posy = (600 - ArrWinInfo[0].p_sizey) / 2;

	Lcd_Init();
	Lcd_Win_Init(0, 1);
	_Lcd_Brightness_Control(8);

	_Lcd_Select_Display_Frame_Buffer(0, 0);
	_Lcd_Select_Draw_Frame_Buffer(0, 0);
	_Lcd_Clr_Screen();

	for(;;)
	{
		int index = 0;
		//CAR SPEED VALUE
		int car_speed = _Get_Car_Speed();
		//CAR STATUS
		int car_status = _Get_Car_Status();
		_Uart_Printf(">>Car Speed : %d\n", car_speed);
		for(; index < 5 ; index++){
			if(car_status == 1){		//�޹���
				_Uart_Printf(">>=================�޹��� ===============\n");
				_Lcd_Draw_BMP(0,0,warning_img);
			}else if(car_status == 2){	//������
				_Uart_Printf(">> @@@@@@@@@@@@@@@@������ @@@@@@@@@@@@@@@@\n");
				_Lcd_Draw_BMP(0,0,warning_img);
			}else{						//����
				_Lcd_Draw_BMP(0,0,img[index]);
			}
			_Delay(car_speed);
			_Lcd_Clr_Screen();
		}
	}
}
