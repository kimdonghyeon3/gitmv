#include "Device_Driver.h"

#define DELAY	8000

void Main(void)
{
	Uart_Printf(">>APP1 => UART Print, RO-BASE = 0x44100000 \n");

	for(;;)
	{
		Uart_Printf("98\n");
		Delay(DELAY);
		Uart_Printf("99\n");
		Delay(DELAY);
		Uart_Printf("100\n");
	}
}
