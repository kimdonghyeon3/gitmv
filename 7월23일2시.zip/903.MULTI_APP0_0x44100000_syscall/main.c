#include "Device_Driver.h"

//#include ".\images\image0.h"
//#include ".\images\img101.h"
#include ".\images\imgf1.h"
#include ".\images\imgf2.h"
#include ".\images\imgf3.h"
#include ".\images\imgf4.h"

#define BLACK	0x0000
#define WHITE	0xffff
#define BLUE	0x001f
#define GREEN	0x07e0
#define RED		0xf800
#define YELLOW	0xffe0
#define VIOLET	0xf81f
#define DELAY	3000

WIN_INFO_ST ArrWinInfo[5];

const unsigned short * img[]={imgf4, imgf1, imgf2, imgf3};

void Main(void)
{
	_Uart_Printf(">>APP0 => LCD Display\n");

	ArrWinInfo[0].bpp_mode = BPPMODE_16BPP_565;
	ArrWinInfo[0].bytes_per_pixel = 2;
	ArrWinInfo[0].p_sizex = 1024;
	ArrWinInfo[0].p_sizey = 600;
	ArrWinInfo[0].v_sizex = 1024;
	ArrWinInfo[0].v_sizey = 600;
	//ArrWinInfo[0].posx = (1024 - ArrWinInfo[0].p_sizex) / 2;
	//ArrWinInfo[0].posy = (600 - ArrWinInfo[0].p_sizey) / 2;
	ArrWinInfo[0].posx = (1024 - ArrWinInfo[0].p_sizex) / 2;
	ArrWinInfo[0].posy = (600 - ArrWinInfo[0].p_sizey) / 2;

	_Lcd_Init(ArrWinInfo);
	_Lcd_Win_Init(0, 1, ArrWinInfo);
	_Lcd_Brightness_Control(8);

	_Lcd_Select_Display_Frame_Buffer(0, 0);
	_Lcd_Select_Draw_Frame_Buffer(0, 0);
	_Lcd_Clr_Screen(ArrWinInfo);

	_Lcd_Draw_Back_Color(0x679, ArrWinInfo);
	for(;;)
	{

		_Lcd_Draw_BMP(0,0,img[2]);
		_Delay(DELAY);
		//_Lcd_Clr_Screen(ArrWinInfo);

		_Lcd_Draw_BMP(0,0,img[3]);
		_Delay(DELAY);
		//_Lcd_Clr_Screen(ArrWinInfo);

		_Lcd_Draw_BMP(0,0,img[0]);
		_Delay(DELAY);
		//_Lcd_Clr_Screen(ArrWinInfo);

		_Lcd_Draw_BMP(0,0,img[1]);
		_Delay(DELAY);
		//_Lcd_Clr_Screen(ArrWinInfo);
	}
}
