/*
 * car.c
 *
 *  Created on: 2024. 7. 23.
 *      Author: donghyeon.kim
 */
#include "device_driver.h"

unsigned int car_speed = SPEED_DEFAULT;

unsigned int Get_Car_Speed(void){
	return car_speed;
}
