#include "4412_addr.h"
#include "macro.h"
#include "option.h"

#include <malloc.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <locale.h>
#include <sys/stat.h>
#include <sys/types.h>

// runtime.c
extern void Delay(unsigned int v);

// key.c
extern int _Key_Get_Key_Pressed(void);
extern void _Key_Poll_Init(void);;
extern void _Key_Wait_Key_Released(void);
extern int _Key_Wait_Key_Pressed(void);
extern void _Key_ISR_Init(void);

//graphics.c

typedef struct {
	unsigned int posx;
	unsigned int posy;
	unsigned int p_sizex;
	unsigned int p_sizey;
	unsigned int v_sizex;
	unsigned int v_sizey;
	unsigned int bytes_per_pixel;
	unsigned int bpp_mode;
}WIN_INFO_ST;

extern void _Uart1_Send_Byte(char data);
extern void _Uart1_Send_String(const char *pt);
extern char _Uart1_Get_Char(void);
extern char _Uart1_Get_Pressed(void);
extern int 	_Uart1_GetIntNum(void);
extern int 	_Key_Get_Key_Pressed(void);
\
extern void _Delay(unsigned int v);
extern void _Uart_Printf(const char *fmt,...);
extern void _Lcd_Put_Pixel(int x,int y, unsigned short color, WIN_INFO_ST ArrWinInfo[]);
extern void * _Lcd_Get_Pixel_Address(int x,int y, WIN_INFO_ST ArrWinInfo[]);
extern unsigned int _Lcd_Get_Pixel(int x,int y, WIN_INFO_ST ArrWinInfo[]);
extern void _Lcd_Clr_Screen(WIN_INFO_ST ArrWinInfo[]);
extern void _Lcd_Draw_Back_Color(int color, WIN_INFO_ST ArrWinInfo[]);
extern void _Lcd_Get_Info_BMP(int * x, int  * y, const unsigned short int *fp);
extern void _Lcd_Draw_BMP(int x, int y, const unsigned short int *fp);
extern void _Lcd_Select_Draw_Frame_Buffer(int win_id,int buf_num);
extern void _Lcd_Select_Display_Frame_Buffer(int win_id,int buf_num);
extern void _Lcd_Wait_Blank(void);
extern void _Lcd_Draw_Image(int x, int y, const unsigned short int *fp, int width, int height);
extern void _Lcd_Brightness_Control(int level);
extern void _Lcd_Draw_BMP_File_24bpp(int x, int y, void *fp);
extern void _Lcd_Draw_STACK(void);
extern void _Lcd_Printf(int x, int y, int color, int bkcolor, int zx, int zy, char *fmt,...);
extern void _Lcd_Draw_Bar(int x1, int y1, int x2, int y2, int color);
extern void _Lcd_Draw_Line(int x1,int y1,int x2,int y2,int color);
extern void _Lcd_Win_Init(int id,int en, WIN_INFO_ST ArrWinInfo[]);
extern void _Lcd_Init(WIN_INFO_ST ArrWinInfo[]);
