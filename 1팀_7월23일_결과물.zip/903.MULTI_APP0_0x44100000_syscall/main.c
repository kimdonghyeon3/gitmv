#include "Device_Driver.h"

//#include ".\images\image0.h"
//#include ".\images\img101.h"
//#include ".\images\imgf1.h"
//#include ".\images\imgf3.h"
//#include ".\images\imgf4.h"
//#include ".\images\imgf4.h"
//#include ".\images\imgf1_sunset.h"
#include ".\images\imgf2_sunset.h"
#include ".\images\imgf3_sunset.h"
#include ".\images\imgf4_sunset.h"
#include ".\images\imgf5_sunset.h"

#define BLACK	0x0000
#define WHITE	0xffff
#define BLUE	0x001f
#define GREEN	0x07e0
#define RED		0xf800
#define YELLOW	0xffe0
#define VIOLET	0xf81f
#define DELAY	5000

WIN_INFO_ST ArrWinInfo[5];
WIN_INFO_ST ArrWinInfo_2[5];

unsigned int car_speed;

//const unsigned short * img[]={imgf1, imgf3, imgf4, imgf1_sunset, imgf3_sunset};
const unsigned short * img[]={imgf2_sunset, imgf3_sunset, imgf4_sunset, imgf5_sunset};

void Main(void)
{
	int i=0;
	int j=0;
	_Uart_Printf(">>APP0 => LCD Display\n");

	ArrWinInfo[0].bpp_mode = BPPMODE_16BPP_565;
	ArrWinInfo[0].bytes_per_pixel = 2;
	ArrWinInfo[0].p_sizex = 1024;
	ArrWinInfo[0].p_sizey = 600;
	ArrWinInfo[0].v_sizex = 1024;
	ArrWinInfo[0].v_sizey = 600;
	ArrWinInfo[0].posx = (1024 - ArrWinInfo[0].p_sizex) / 2;
	ArrWinInfo[0].posy = (600 - ArrWinInfo[0].p_sizey) / 2;

	ArrWinInfo_2[0].bpp_mode = BPPMODE_16BPP_565;
	ArrWinInfo_2[0].bytes_per_pixel = 2;
	ArrWinInfo_2[0].p_sizex = 1024;
	ArrWinInfo_2[0].p_sizey = 600;
	ArrWinInfo_2[0].v_sizex = 1024;
	ArrWinInfo_2[0].v_sizey = 600;
	ArrWinInfo_2[0].posx = (1024 - 600) / 2;
	ArrWinInfo_2[0].posy = (600 - ArrWinInfo[0].p_sizey) / 2;


	_Lcd_Init(ArrWinInfo);
	_Lcd_Win_Init(0, 1, ArrWinInfo);
	_Lcd_Brightness_Control(8);

	_Lcd_Select_Display_Frame_Buffer(0, 0);
	_Lcd_Select_Draw_Frame_Buffer(0, 0);
	_Lcd_Clr_Screen(ArrWinInfo);

	_Lcd_Draw_Back_Color(0x284b, ArrWinInfo_2);
	for(;;)
	{
		//_Lcd_Printf(600, 0, 0xffff, 0x284b, 2, 4, car_speed/1000 + '0');
		//_Lcd_Printf(630, 0, 0xffff, 0x284b, 2, 4, car_speed/100 + '0');
		//_Lcd_Printf(660, 0, 0xffff, 0x284b, 2, 4, car_speed/10 + '0');
		_Lcd_Printf(700, 0, 0xffff, 0x284b, 2, 4, "50 KM / h");
		int index = 0;
		//_Lcd_Printf(0, 0, 0x0000 , 0x284b, 0, 0, "35KM/h");
		for(; index < sizeof(img)/sizeof(unsigned short *) ; index++){
			car_speed = _Get_Car_Speed();
			//_Uart_Printf(">>car_speed : %d\n",car_speed);
			_Lcd_Draw_BMP(0,0,img[index]);
			_Delay(car_speed);
			//_Uart_Printf(">>car_speed : %d\n",car_speed);
		}
	}

	/*
	_Lcd_Draw_Back_Color(0x679, ArrWinInfo_2);
	for(;;)
	{
		_Lcd_Draw_Back_Color(0x679, ArrWinInfo_2);
		for(i=0;i<10;i++){
			_Lcd_Draw_BMP(0,0,img[0]);
			_Delay(DELAY);
			//_Lcd_Clr_Screen(ArrWinInfo);

			_Lcd_Draw_BMP(0,0,img[1]);
			_Delay(DELAY);
			//_Lcd_Clr_Screen(ArrWinInfo);

			_Lcd_Draw_BMP(0,0,img[2]);
						_Delay(DELAY);
		}

		_Lcd_Draw_Back_Color(0x284b, ArrWinInfo_2);
		for(i=0;i<10;i++){
			_Lcd_Draw_BMP(0,0,img[3]);
			_Delay(DELAY);
			//_Lcd_Clr_Screen(ArrWinInfo);

			_Lcd_Draw_BMP(0,0,img[4]);
			_Delay(DELAY);
			//_Lcd_Clr_Screen(ArrWinInfo);
		}
	}*/
}
