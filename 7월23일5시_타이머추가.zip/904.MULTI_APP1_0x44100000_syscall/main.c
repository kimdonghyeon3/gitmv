#include "Device_Driver.h"
#define DELAY	8000

WIN_INFO_ST ArrWinInfo[5];

const unsigned short * img; //= warning;

void Main(void)
{
	_Uart_Printf(">>APP1 => UART Print, RO-BASE = 0x44100000 \n");

	ArrWinInfo[0].bpp_mode = BPPMODE_16BPP_565;
	ArrWinInfo[0].bytes_per_pixel = 2;
	ArrWinInfo[0].p_sizex = 1024;
	ArrWinInfo[0].p_sizey = 600;
	ArrWinInfo[0].v_sizex = 1024;
	ArrWinInfo[0].v_sizey = 600;
	//ArrWinInfo[0].posx = (1024 - ArrWinInfo[0].p_sizex) / 2;
	//ArrWinInfo[0].posy = (600 - ArrWinInfo[0].p_sizey) / 2;
	ArrWinInfo[0].posx = (1024 - ArrWinInfo[0].p_sizex) / 2;
	ArrWinInfo[0].posy = (600 - ArrWinInfo[0].p_sizey) / 2;

	_Lcd_Init(ArrWinInfo);
	_Lcd_Win_Init(0, 1, ArrWinInfo);
	_Lcd_Brightness_Control(8);

	_Lcd_Select_Display_Frame_Buffer(0, 0);
	_Lcd_Select_Draw_Frame_Buffer(0, 0);
	_Lcd_Clr_Screen(ArrWinInfo);

	for(;;)
	{
		//������ 5�� ���ȴٸ�, waring ��� ����
		if(_Check_Accel()){
			_Lcd_Draw_BMP(0,0,img);
		}else if(_Check_Break()){	//�극��ũ 5�� ���ȴٸ�, �극��ũ �ȳ� ���� ����
			_Lcd_Printf(900, 0, 0xff,0x0, 2, 4, "brak�� ��� �־��");
		}else{
			_Lcd_Clr_Screen(ArrWinInfo);
		}
	}
}
